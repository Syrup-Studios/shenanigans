# Colorized Antique Atlas 4

This resource pack targets Minecraft 1.21.1 and Antique Atlas 3.1.2+1.21. It replaces 145 Antique Atlas tile textures with colorized textures. Enable it in Options > Resource Packs.

`texture-map.json` lists each replaced tile and its original texture name. The PNG files are unchanged copies from Colorized Antique Atlas by TheNolle v0.0.9. The original archive has no license or credits file. The included Antique Atlas license does not set terms for these textures. This pack includes no Compat support. In-game appearance coverage has not been fully checked.
